# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  
end